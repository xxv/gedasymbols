#!/bin/sh

# sample conversion from imperial to metric units
echo 'Starting sample conversion from imperial to metric units.'
../bin/linux/amd64/gfuc --in dhvqfn16.fp --out dhvqfn16-converted.fp --mil2mm

# sample conversion from metric to imperial units
echo 'Starting sample conversion from metric to imperial units.'
../bin/linux/amd64/gfuc --in dhvqfn16-converted.fp --out dhvqfn16-backconverted.fp --mm2mil

