#!/usr/bin/ruby
#
# footgen.rb - Footprint Generator for PCB
# Copyright (C) 2015 Edward C Hennessy
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

require 'gio2'
require 'gtk3'

class Box

    attr_accessor :x0
    attr_accessor :y0
    attr_accessor :x1
    attr_accessor :y1

    def initialize params = {}
        @x0 = params[:x0] || 0.0
        @y0 = params[:y0] || 0.0
        @x1 = params[:x1] || 0.0
        @y1 = params[:y1] || 0.0
    end

    def expand delta
        @x0 -= delta
        @y0 -= delta
        @x1 += delta
        @y1 += delta
    end

    def self.union box1, box2
        if (box1 == nil)
            return box2
        elsif (box2 == nil)
            return box1
        else
            return Box.new(
                :x0 => [box1.x0, box1.x1, box2.x0, box2.x1].min,
                :y0 => [box1.y0, box1.y1, box2.y0, box2.y1].min,
                :x1 => [box1.x0, box1.x1, box2.x0, box2.x1].max,
                :y1 => [box1.y0, box1.y1, box2.y0, box2.y1].max
                )
        end
    end

end


module Pcb

    ##
    # PCB attribute
    #
    class Attribute

        ##
        # the name of the attribute, convertable to a string
        #
        attr_accessor :name


        ##
        # the value of the attribute, convertable to a string
        #
        attr_accessor :value


        ##
        # initialize an attribute
        #
        # [name] the name of the attribute
        # [value] the value of the attribute
        def initialize name, value
            @name = name
            @value = value
        end


        ##
        # convert this attribute to a string
        #
        def to_s
            "\tAttribute(\"#{@name}\" \"#{@value}\")"
        end

    end


    ##
    # provides a blank line in the footprint
    #
    class Blank

        ##
        #
        #
        def draw context
        end

        ##
        # returns an empty string to create a blank line in the output
        #
        def to_s
            ""
        end

    end


    ##
    # PCB coordinte
    #
    class Coord

        include Comparable

        ##
        #
        #
        ROUND_DIGITS = 10

        ##
        #
        #
        UNITS_MIL = "mil"

        ##
        #
        #
        UNITS_MM = "mm"


        def self.create_key from, to
            "#{from}->#{to}"
        end

        ##
        #
        #
        CONVERSION_TABLE = {
            create_key(UNITS_MIL, UNITS_MIL) => 1.0,
            create_key(UNITS_MM,  UNITS_MM ) => 1.0,
            create_key(UNITS_MM,  UNITS_MIL) => 25.4,
            create_key(UNITS_MIL, UNITS_MM)  => (1.0 / 25.4)
            }


        ##
        # a string containing the units for this coordinate
        #
        attr_accessor :units


        ##
        # a numeric type containing the value of this coordinate
        #
        attr_accessor :value


        ##
        #
        #
        def initialize value = 0.0, units = UNITS_MM
            @value = value
            @units = units
        end


        ##
        #
        #
        def self.parse string
            if string =~ /mm$/ then
                Coord.new string.to_f, UNITS_MM
            elsif string =~ /mil$/ then
                Coord.new string.to_f, UNITS_MIL
            else
                Coord.new string.to_f
            end
        end


        ##
        #
        #
        def <=> other
            value <=> other.value
        end


        ##
        #
        #
        def + other
            Coord.new (@value + other.convert(@units).value), @units
        end


        ##
        #
        #
        def - other
            Coord.new (@value - other.convert(@units).value), @units
        end


        ##
        #
        #
        def / other
            Coord.new (@value / other), @units
        end


        ##
        #
        #
        def * other
            Coord.new (@value * other), @units
        end


        ##
        #
        #
        def convert target
            factor = CONVERSION_TABLE[Coord.create_key @units, target]
            Coord.new @value * factor, target
        end


        ##
        #
        #
        def to_f units = UNITS_MM
            convert(units).value.to_f
        end


        ##
        #
        #
        def to_s space = false
            "#{@value.round ROUND_DIGITS}#{space ? ' ':''}#{@units}"
        end

    end


    ##
    # PCB Element
    #
    class Element

        ##
        # The direction for text: 0, 90, 180, or 270
        #
        TEXT_DIRECTION = 0


        ##
        # The size for text as a percentage
        #
        TEXT_SIZE = 100


        ##
        # The x insertion point for the footprint
        #
        INSERT_X = Pcb::Coord.new 0.0


        ##
        # The y insertion point for the footprint
        #
        INSERT_Y = Pcb::Coord.new 0.0


        ##
        # The description of the element
        #
        attr_accessor :description


        ##
        # The name (refdes) of the element
        #
        attr_accessor :name


        ##
        # The PCB objects in this element
        #
        attr_reader :objects


        ##
        # The x location for the text (name, description, or value)
        #
        attr_accessor :text_x


        ##
        # The y location for the text (name, description, or value)
        #
        attr_accessor :text_y


        ##
        # The value of the element
        #
        attr_accessor :value


        ##
        #
        # [:name]
        # [:description]
        # [:value]
        # [:text_x]
        # [:text_y]
        def initialize params = {}
            @name = params[:name] || ""
            @description = params[:description] || ""
            @value = params[:value] || ""

            @text_x = params[:text_x] || 0.0
            @text_y = params[:text_y] || 0.0

            @objects = []
        end


        #
        #
        #
        def to_s
            string = "Element["

            string << "\"\" "
            string << "\"#{@description}\" "
            string << "\"#{@name}\" "
            string << "\"#{@value}\" "
            string << "#{INSERT_X} "
            string << "#{INSERT_Y} "
            string << "#{@text_x} "
            string << "#{@text_y} "
            string << "#{TEXT_DIRECTION} "
            string << "#{TEXT_SIZE} "
            string << "\"\"] (\n"

            for object in @objects do
                string << "#{object}\n"
            end

            string << "\t)"

            return string
        end

    end


    ##
    # PCB ElementLine
    #
    class ElementLine

        ##
        #
        #
        DEFAULT_THICKNESS = Coord.new 0.3, Coord::UNITS_MM


        ##
        #
        #
        attr_accessor :x0


        ##
        #
        #
        attr_accessor :y0


        ##
        #
        #
        attr_accessor :x1


        ##
        #
        #
        attr_accessor :y1


        ##
        #
        #
        attr_accessor :thickness


        ##
        #
        #
        def initialize params = {}
            @x0 = params[:x0] || 0.0
            @y0 = params[:y0] || 0.0
            @x1 = params[:x1] || 0.0
            @y1 = params[:y1] || 0.0
            @thickness = params[:thickness] || DEFAULT_THICKNESS
        end


        # extents of the silkscreen centerline
        def extents
            return Box.new(
                :x0 => [@x0, @x1].min,
                :y0 => [@y0, @y1].min,
                :x1 => [@x0, @x1].max,
                :y1 => [@y0, @y1].max
                )
        end


        ##
        #
        #
        def to_s
            "\tElementLine[#{@x0} #{@y0} #{@x1} #{@y1} #{@thickness}]"
        end

    end


    ##
    # PCB Pad
    #
    class Pad

        DEFAULT_CLEARANCE = Pcb::Coord.new 0.25, Pcb::Coord::UNITS_MM

        DEFAULT_SOLDERMASK_RELIEF = DEFAULT_CLEARANCE / 2.0

        def self.new_clw params = {}
            aperture = [params[:length], params[:width]].min

            x0 = params[:xcenter] + (params[:length] - aperture) / -2.0
            y0 = params[:ycenter] + (params[:width] - aperture) / -2.0
            x1 = params[:xcenter] + (params[:length] - aperture) / 2.0
            y1 = params[:ycenter] + (params[:width] - aperture) / 2.0

            return Pad.new(
                :x0 => x0,
                :y0 => y0,
                :x1 => x1,
                :y1 => y1,
                :aperture => aperture,
                :clearance => params[:clearance],
                :soldermask_relief => params[:soldermask_relief],
                :number => params[:number]
                )
        end

        def initialize params = {}
            @x0 = params[:x0] || 0.0
            @y0 = params[:y0] || 0.0
            @x1 = params[:x1] || 0.0
            @y1 = params[:y1] || 0.0
            @aperture = params[:aperture] || 1.0
            @clearance = params[:clearance] || DEFAULT_CLEARANCE
            @soldermask_relief = params[:soldermask_relief] || DEFAULT_SOLDERMASK_RELIEF
            @number = params[:number] || ""
        end


        # extents of the copper pad
        def extents
            return Box.new(
                :x0 => [@x0, @x1].min - (@aperture / 2.0),
                :y0 => [@y0, @y1].min - (@aperture / 2.0),
                :x1 => [@x0, @x1].max + (@aperture / 2.0),
                :y1 => [@y0, @y1].max + (@aperture / 2.0)
                )
        end

        def to_s
            "\tPad["\
                "#{@x0} "\
                "#{@y0} "\
                "#{@x1} "\
                "#{@y1} "\
                "#{@aperture} "\
                "#{@clearance * 2.0} "\
                " #{@aperture + @soldermask_relief * 2.0} "\
                "\"#{@number}\" "\
                "\"#{@number}\" "\
                "\"square\"]"
        end
    end

end

module Tool

    class Outline

        def initialize params = {}
            @extend = params[:extend] || 0.0
            @polarity = params[:polarity] || false
        end

        def generate box, thickness

            delta = thickness * 2.0 * @extend

            #top side
            yield Pcb::ElementLine.new(
                :x0 => box.x0 - delta,
                :y0 => box.y0,
                :x1 => box.x1,
                :y1 => box.y0,
                :thickness => thickness
                )

            #right side
            yield Pcb::ElementLine.new(
                :x0 => box.x1,
                :y0 => box.y0,
                :x1 => box.x1,
                :y1 => box.y1,
                :thickness => thickness
                )

            #bottom side
            yield Pcb::ElementLine.new(
                :x0 => box.x1,
                :y0 => box.y1,
                :x1 => box.x0 - delta,
                :y1 => box.y1,
                :thickness => thickness
                )

            #left side
            yield Pcb::ElementLine.new(
                :x0 => box.x0,
                :y0 => box.y1,
                :x1 => box.x0,
                :y1 => box.y0,
                :thickness => thickness
                )

            if @polarity then
                # polarity line
                yield Pcb::ElementLine.new(
                    :x0 => box.x0 - thickness * 2.0,
                    :y0 => box.y1,
                    :x1 => box.x0 - thickness * 2.0,
                    :y1 => box.y0,
                    :thickness => thickness
                    )
            end
        end

    end

end

module Gui

    ##
    # a widget for selecting a silkscreen outline
    #
    class OutlineCombo < Gtk::Bin

        type_register

        signal_new(
            "changed",
            GLib::Signal::RUN_FIRST,
            nil,
            nil,
            )

        ##
        # the Gtk::ListStore column containing the name
        #
        COLUMN_NAME = 0


        ##
        # the Gtk::ListStore column containing the outline object
        #
        COLUMN_OBJECT = 1


        ##
        #
        #
        DEFAULT_OUTLINE = Tool::Outline.new(
            :extend => 0.0,
            :polarity => false
            )


        ##
        #
        #
        def initialize

            super

            @outline_model = create_model
            @outline_combo = create_combo @outline_model

            @outline_combo.signal_connect "changed" do
                self.signal_emit("changed")
            end

            add @outline_combo
        end


        ##
        #
        #
        def create_combo model

            combo = Gtk::ComboBox.new :model => model

            renderer = Gtk::CellRendererPixbuf.new

            combo.pack_start renderer, true
            #combo.set_attributes renderer, {:text => COLUMN_NAME}

            renderer = Gtk::CellRendererText.new
            renderer.alignment = Pango::Layout::Alignment::RIGHT

            combo.pack_start renderer, true
            combo.set_attributes renderer, {:text => COLUMN_NAME}

            combo.set_active 0

            return combo
        end


        ##
        #
        #
        def create_model

            model = Gtk::ListStore.new String, Object

            iter = model.append

            model.set_value(
                iter,
                COLUMN_NAME,
                "Non-polarized"
                )

            model.set_value(
                iter,
                COLUMN_OBJECT,
                Tool::Outline.new(
                    :extend => 0.0,
                    :polarity => false
                    )
                )

            iter = model.append

            model.set_value(
                iter,
                COLUMN_NAME,
                "Polarized A"
                )

            model.set_value(
                iter,
                COLUMN_OBJECT,
                Tool::Outline.new(
                    :extend => 1.0,
                    :polarity => true
                    )
                )

            iter = model.append

            model.set_value(
                iter,
                COLUMN_NAME,
                "Polarized B"
                )

            model.set_value(
                iter,
                COLUMN_OBJECT,
                Tool::Outline.new(
                    :extend => 0.0,
                    :polarity => true
                    )
                )

            return model
        end


        ##
        # get the currently selected outline
        #
        def outline

            iter = @outline_combo.active_iter

            if iter then
                return @outline_model.get_value iter, COLUMN_OBJECT
            else
                return DEFAULT_OUTLINE
            end
        end


        def signal_do_changed
        end

    end


    #
    #
    #
    class MyEditor < Gtk::Bin

        type_register

        signal_new(
            "change",
            GLib::Signal::RUN_FIRST,
            nil,
            nil,
            )

        BORDER_WIDTH = 10
        GRID_SPACING = 5
        LABEL_INDENT = 20


        #
        #
        #
        def initialize

            super

            @general_buffers = {
                :name => createEntryBuffer("D1"),
                :description => createEntryBuffer("Diode, Molded, SMA"),
                :value => createEntryBuffer("")
                }

            @geometry_buffers = {
                :package_length    => createEntryBuffer("5.2 mm"),
                :package_width     => createEntryBuffer("2.6 mm"),

                :pad_length        => createEntryBuffer("2.5 mm"),
                :pad_width         => createEntryBuffer("1.7 mm"),
                :pad_spacing       => createEntryBuffer("4.0 mm"),

                :pad_clearance         => createEntryBuffer(Pcb::Pad::DEFAULT_CLEARANCE.to_s true),
                :pad_soldermask_relief => createEntryBuffer(Pcb::Pad::DEFAULT_SOLDERMASK_RELIEF.to_s true),

                :silkscreen_package_offset => createEntryBuffer("0.25 mm"),
                :silkscreen_pad_offset     => createEntryBuffer("0.25 mm"),
                :silkscreen_thickness      => createEntryBuffer("0.3 mm"),
                }

            @attribute_buffers = {
                "author" => createEntryBuffer("'your name here'"),
                "copyright" => createEntryBuffer("(C) 2015 'your name here'"),
                "dist-license" => createEntryBuffer("GPL"),
                "use-license" => createEntryBuffer("Unlimited")
                }

            set_border_width BORDER_WIDTH

            grid = create_grid

            grid.orientation = Gtk::Orientation::VERTICAL

            grid.add create_general_section
            grid.add create_geometry_section
            grid.add create_license_section

            add grid
        end


        #
        #
        #
        def create_entry buffer

            entry = Gtk::Entry.new

            entry.buffer = buffer
            entry.hexpand = true
            entry.xalign = 1.0

            return entry
        end


        #
        #
        #
        def createEntryBuffer contents = ""

            buffer = Gtk::EntryBuffer.new contents

            buffer.signal_connect "notify::text" do
                on_change
            end

            return buffer
        end


        #
        #
        #
        def create_expander text, widget

            expander = Gtk::Expander.new(
                "<b>#{text}</b>",
                 true
                 )

            expander.use_markup = true
            expander.expanded = true

            expander.add widget

            return expander
        end


        #
        #
        #
        def create_general_section

            grid = create_grid

            widgets = [
                [
                    create_label("Refdes"),
                    create_entry(@general_buffers[:name])
                    ],
                [
                    create_label("Description"),
                    create_entry(@general_buffers[:description])
                    ],
                [
                    create_label("Value"),
                    create_entry(@general_buffers[:value])
                    ]
                ]

            widgets.each.with_index do |widget, index|
                grid.attach widget[0], 0, index, 1, 1
                grid.attach widget[1], 1, index, 1, 1
            end

            return create_expander "General", grid
        end


        #
        #
        #
        def create_geometry_section

            grid = create_grid

            widgets = [
                [
                    create_label("Package Length"),
                    create_entry(@geometry_buffers[:package_length])
                    ],
                [
                    create_label("Package Width"),
                    create_entry(@geometry_buffers[:package_width])
                    ],
                [
                    create_label("Pad Length"),
                    create_entry(@geometry_buffers[:pad_length])
                    ],
                [
                    create_label("Pad Width"),
                    create_entry(@geometry_buffers[:pad_width])
                    ],
                [
                    create_label("Pad Spacing (BSC)"),
                    create_entry(@geometry_buffers[:pad_spacing])
                    ],
                [
                    create_label("Pad Clearance"),
                    create_entry(@geometry_buffers[:pad_clearance])
                    ],
                [
                    create_label("Pad Soldermask Relief"),
                    create_entry(@geometry_buffers[:pad_soldermask_relief])
                    ],
                [
                    create_label("Silkscreen Package Offset"),
                    create_entry(@geometry_buffers[:silkscreen_package_offset])
                    ],
                [
                    create_label("Silkscreen Pad Offset"),
                    create_entry(@geometry_buffers[:silkscreen_pad_offset])
                    ],
                [
                    create_label("Silkscreen Thickness"),
                    create_entry(@geometry_buffers[:silkscreen_thickness])
                    ],
                [
                    create_label("Silkscreen Outline"),
                    create_outline_combo
                    ]
                ]

            widgets.each.with_index do |widget, index|
                grid.attach widget[0], 0, index, 1, 1
                grid.attach widget[1], 1, index, 1, 1
            end

            return create_expander "Geometry", grid
        end


        #
        #
        #
        def create_grid

            grid = Gtk::Grid.new

            grid.column_spacing = GRID_SPACING
            grid.row_spacing = GRID_SPACING

            return grid
        end


        #def createImage(self):
        #    image = Gtk.Image()
        #    image.set_from_file("drawing.svg")
        #    return self.createExpander("Reference Drawing", image)


        #
        #
        #
        def create_label text

            label = Gtk::Label.new(text)

            label.set_alignment 0.0, 0.5
            label.margin_left = LABEL_INDENT

            return label
        end


        #
        #
        #
        def create_license_section

            grid = create_grid

            widgets = [
                [
                    create_label("Author"),
                    create_entry(@attribute_buffers["author"])
                    ],
                [
                    create_label("Copyright"),
                    create_entry(@attribute_buffers["copyright"])
                    ],
                [
                    create_label("Distribution License"),
                    create_entry(@attribute_buffers["dist-license"])
                    ],
                [
                    create_label("Use License"),
                    create_entry(@attribute_buffers["use-license"])
                    ]
                ]

            widgets.each.with_index do |widget, index|
                grid.attach widget[0], 0, index, 1, 1
                grid.attach widget[1], 1, index, 1, 1
            end

            return create_expander "License", grid
        end


        #
        #
        #
        def create_unit_label

            label = Gtk::Label.new("mm")

            label.set_alignment 0.0, 0.5

            return label
        end


        ##
        #
        #
        def create_outline_combo

            @outline_combo = OutlineCombo.new

            @outline_combo.signal_connect "changed" do
                on_change
            end

            return @outline_combo
        end


        def coord symbol
            Pcb::Coord.parse @geometry_buffers[symbol].text
        end

        #
        #
        #
        def create_footprint

            element = Pcb::Element.new(
                :name => @general_buffers[:name].text,
                :description => @general_buffers[:description].text,
                :value => @general_buffers[:value].text
                )

            element.objects << pad1 = Pcb::Pad.new_clw(
                :xcenter => coord(:pad_spacing) / -2.0,
                :ycenter => Pcb::Coord.new(0.0),
                :length => coord(:pad_length),
                :width => coord(:pad_width),
                :clearance => coord(:pad_clearance),
                :soldermask_relief => coord(:pad_soldermask_relief),
                :number => "1"
                )

            element.objects << pad2 = Pcb::Pad.new_clw(
                :xcenter => coord(:pad_spacing) / 2.0,
                :ycenter => Pcb::Coord.new(0.0),
                :length => coord(:pad_length),
                :width => coord(:pad_width),
                :clearance => coord(:pad_clearance),
                :soldermask_relief => coord(:pad_soldermask_relief),
                :number => "2"
                )

            element.objects << Pcb::Blank.new

            outline = @outline_combo.outline

            pad_box = Box.union pad1.extents, pad2.extents

            pad_box.expand coord :silkscreen_pad_offset
            pad_box.expand coord(:silkscreen_thickness) / 2.0

            package_box = Box.new(
                :x0 => coord(:package_length) / -2.0,
                :y0 => coord(:package_width) / -2.0,
                :x1 => coord(:package_length) / 2.0,
                :y1 => coord(:package_width) / 2.0
                )

            package_box.expand coord :silkscreen_package_offset
            package_box.expand coord(:silkscreen_thickness) / 2.0

            temp_objects = []


            outline.generate((Box.union package_box, pad_box), coord(:silkscreen_thickness)) do |object|
                temp_objects << object
            end

            element.objects.concat temp_objects

            silk_extents = temp_objects.map do |object|
                object.extents
            end

            final = silk_extents.reduce do |o1, o2|
                Box.union o1, o2
            end

            element.text_x = final.x0
            element.text_y = final.y1 + Pcb::Coord.new(0.4, Pcb::Coord::UNITS_MM)

            element.objects << Pcb::Blank.new

            @attribute_buffers.each do |name, buffer|
                element.objects << Pcb::Attribute.new(name, buffer.text)
            end

            return element
        end



        def signal_do_change
        end


        def on_change
            self.signal_emit("change")
        end

    end


    ##
    # A graphical view for a PCB element
    #
    class MyViewer < Gtk::Bin

        type_register

        ##
        #
        #
        def element
            @element
        end


        ##
        #
        #
        def element= element
            @element = element
            @canvas.queue_draw
        end


        ##
        #
        #
        def initialize

            super

            @canvas = Gtk::DrawingArea.new

            @canvas.signal_connect "draw" do |widget, context|
                on_draw widget, context
            end

            add @canvas
        end


        ##
        #
        #
        def on_draw widget, context

            if @element then

                r_limit = 10000.0
                r_scale = 100.0

                recording_surface = Cairo::RecordingSurface.new(
                    0.0,
                    0.0,
                    r_limit,
                    r_limit,
                    Cairo::Content::COLOR
                    )

                temp_context = Cairo::Context.new recording_surface
                temp_context.translate r_limit / 2.0, r_limit / 2.0
                temp_context.scale r_scale, r_scale

                @element.draw temp_context

                ink = recording_surface.ink_extents

                context.translate(
                    widget.allocation.width / 2.0,
                    widget.allocation.height / 2.0
                    )

                scale = [
                    0.9 * widget.allocation.width / ink[2],
                    0.9 * widget.allocation.height / ink[3]
                    ].min

                context.scale r_scale * scale, r_scale * scale

                context.translate(
                    ((r_limit - ink[2]) / 2.0 - ink[0]) / r_scale,
                    ((r_limit - ink[3]) / 2.0 - ink[1]) / r_scale
                    )

                @element.draw context
            end
        end


        ##
        #
        #
        class ::Pcb::Element
            def draw context
                @objects.each do |object|
                    object.draw context
                end

                # use cairo toy text API for a quick refdes

                extents = context.text_extents @name
                context.move_to @text_x.to_f, @text_y.to_f + extents.height * 0.1
                context.scale 0.1, 0.1
                context.show_text @name
            end
        end


        ##
        #
        #
        class ::Pcb::Attribute

            def draw context
            end
        end


        ##
        #
        #
        class ::Pcb::Blank

            def draw context
            end
        end

        ##
        #
        #
        class ::Pcb::ElementLine

            def draw context
                context.move_to @x0.to_f, @y0.to_f
                context.line_to @x1.to_f, @y1.to_f
                context.set_line_width @thickness.to_f

                context.set_line_cap Cairo::LINE_CAP_ROUND
                context.set_source_rgb 0.0, 0.0, 0.0

                context.stroke
            end
        end

        class ::Pcb::Pad
            def draw context

                context.move_to @x0.to_f, @y0.to_f

                if [@x0.to_f, @y0.to_f] == [@x1.to_f, @y1.to_f] then
                    context.line_to @x1.to_f + 0.0001, @y1.to_f
                else
                    context.line_to @x1.to_f, @y1.to_f
                end

                context.set_line_cap Cairo::LINE_CAP_SQUARE

                context.set_line_width (@aperture + @soldermask_relief * 2.0).to_f
                context.set_source_rgb 0.3, 0.3, 0.3
                context.stroke_preserve

                context.set_line_width @aperture.to_f
                context.set_source_rgb 0.7, 0.7, 0.7
                context.stroke
            end
        end


    end


    ##
    #
    #
    class MyWindow < Gtk::Window

        type_register

        #install_property(
        #    GLib::Param::String.new(
        #        "element",
        #        "element",
        #        "The state of an IconSet",
        #        "",
        #        GLib::Param::READABLE | GLib::Param::WRITABLE
        #        )
        #    )

        TITLE = "Footprint Generator"

        ##
        #
        #
        def initialize

            super

            signal_connect "destroy" do
                Gtk.main_quit
            end

            #set_default_size 300, 200

            set_window_position Gtk::Window::Position::CENTER

            @editor = MyEditor.new
            @export_dialog = create_export_dialog
            @text_buffer = Gtk::TextBuffer.new
            @graphic_widgets = []

            @editor.signal_connect "change" do
                element = @editor.create_footprint
                @text_buffer.set_text element.to_s
                for widget in @graphic_widgets do
                    widget.element = element
                end
                if element.description.length > 0 then
                    set_title "#{TITLE} - #{element.description}"
                else
                    set_title "#{TITLE}"
                end
            end

            @text_buffer.set_text @editor.create_footprint.to_s

            grid = Gtk::Grid.new
            grid.set_orientation Gtk::Orientation::VERTICAL
            grid.set_hexpand true
            grid.set_vexpand true
            add grid

            grid.add create_main_widget
            grid.add create_button_box

            element = @editor.create_footprint
            for widget in @graphic_widgets do
                widget.element = @editor.create_footprint
            end
            if element.description.length > 0 then
                set_title "#{TITLE} - #{element.description}"
            else
                set_title "#{TITLE}"
            end

            show_all
        end


        ##
        #
        #
        def create_button_box

            box = Gtk::ButtonBox.new :horizontal

            box.set_border_width 20
            box.layout_style = Gtk::ButtonBox::Style::END
            box.set_hexpand true

            box.add create_export_button

            return box
        end


        ##
        #
        #
        def create_export_button

            button = Gtk::Button.new :label => "Export..."

            button.signal_connect "clicked" do
                on_export_footprint
            end

            return button
        end


        ##
        #
        #
        def create_export_dialog

            dialog = Gtk::FileChooserDialog.new(
                :title => "Export Footprint",
                :parent => self,
                :action => Gtk::FileChooser::Action::SAVE
                )

            dialog.add_button "_OK", Gtk::ResponseType::ACCEPT
            dialog.add_button "_Cancel", Gtk::ResponseType::CANCEL

            dialog.do_overwrite_confirmation = true

            return dialog
        end


        ##
        #
        #
        def create_graphic_viewer

            viewer = MyViewer.new

            @graphic_widgets << viewer

            return viewer
        end


        ##
        #
        #
        def create_main_widget

            paned = Gtk::Paned.new :horizontal

            paned.add1 @editor
            paned.add2 create_viewers

            return paned
        end


        ##
        #
        #
        def create_text_viewer

            viewer = Gtk::TextView.new @text_buffer

            viewer.can_focus = false
            viewer.editable = false

            return viewer
        end


        ##
        #
        #
        def create_viewers

            viewers = Gtk::Notebook.new
            viewers.set_border_width 10
            viewers.set_vexpand true

            viewers.append_page create_text_viewer, Gtk::Label.new("Text")
            viewers.append_page create_graphic_viewer, Gtk::Label.new("Graphic")

            return viewers
        end


        ##
        #
        #
        def on_export_footprint

            contents = @editor.create_footprint.to_s

            if @export_dialog.run == Gtk::ResponseType::ACCEPT

                file = Gio::File.new_for_uri @export_dialog.uri

                file.replace do |output|
                    output.write contents
                end
            end

            rescue Gio::IO::Error => error
                show_exception "File Error", error

            ensure
                @export_dialog.hide
        end


        ##
        #
        #
        def show_exception title, error

            dialog = Gtk::MessageDialog.new(
                :parent => self,
                :flags => 0,
                :type => Gtk::MessageType::ERROR,
                :buttons_type => Gtk::MessageDialog::ButtonsType::OK,
                :message => title
                )

            begin
                dialog.secondary_text = error.message

                dialog.run

                ensure
                    dialog.destroy
            end
        end

    end

end


if __FILE__ == $0
    Gtk.init
        window = Gui::MyWindow.new
    Gtk.main
end
