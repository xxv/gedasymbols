#!/usr/bin/perl

# Copyright (C) 2002 Marc Emery
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.


                        ##############################
                        #            sch2svg         #
                        ##############################
#
# This script convert a .sch file from the program gEDA and convert it
# in a SVG (Scalable Vector Graphics) file.
# Send me your comments, patchs, ideas at emem00 at students.hevs.ch.


#####################################
# Changelog
#####################################
# 1.0.0:
#   - start version numbers
# 1.0.1:
#   - fix id error and introduce encodeId
#   - add xml comment about sch2svg version used
# 1.0.2:
#   - remove the changes before 1.0.0 in changelog
#   - add GPL header


#####################################
# TODO
#####################################
# - correct the english comments
# - improve color2SVG
# - improve text positionning
# - improve lib search
# - replace <g> with <symbol> for parts
# - implement net intersections
# - improve encodeId
# - implement embedded parts


#####################################
# BUGS
#####################################
# - parts in verilog, vhdl, font and dec/DS8641_1.sym don't work.
#   The sch files don't conform to the gEDA format.
# - gschem uses "-1" but it's not in the doc
# - What is "rotation" for angle ?
# - detection of '=' in text not attr can be a problem ?
# - In exemples embedded_1.sch, gile-vfo-block_1.sch and  fill_test.sch don't work.


use strict;
use FileHandle; # since 5.000

# public constants
# you can modify this to customize the svg file

my $LIBS_PATH = "/usr/share/gEDA/sym/";

my $STYLE_OF_NET=q[ stroke="green" stroke-width="10" ];
my $STYLE_OF_BUS=q[ stroke="green" stroke-width="10" ];
my $STYLE_OF_PIN=q[ stroke="green" stroke-width="10" ];
my $LINE_MINIMAL_WIDTH= 5;


#############################################################
# IMPLEMENTATION
#############################################################

# private constants
my $VERSION = "1.0.2";
my $TRUE = 1;
my $FALSE = 0;
my $PI = 3.14159265358979;

my %OBJECT_TYPE = (
    "v" => "version",
    "N" => "net",
    "P" => "pin",
    "U" => "bus",
    "L" => "line",
    "T" => "text",
    "C" => "componement",
    "A" => "arc",
    "B" => "box",
    "V" => "circle",
    "F" => "font"
);

my %LINE_TYPE = (
    "0" => "solid",
    "1" => "dotted",
    "2" => "dashed",
    "3" => "center",
    "4" => "phantom" );

my %LINE_END = (
    "0" => "none",
    "1" => "square",
    "2" => "round" );


#####################################
# some tool functions
#####################################

# write the attributes of an hash in XML
# ex.: hash2attr(\%hash, "x","y") = ' x="10" y="-3" '
sub hash2attr {
    my ($hash, @attrlist) = @_;

    my $attr;
    my $out;
    foreach $attr(@attrlist) {
        exists $$hash{$attr} or die("hash2attr: key $attr doesn't exist in hash\n");
        $out .= $attr.q[="].$$hash{$attr}.q[" ];
    }
    return $out;
}

# convert colors from .sch munerical format to SVG colors
#TODO
sub color2SVG {
    return "black";
}

# take the line attribut from an hash and convert it in SVG line format.
sub lineAttr {
    my (%hash) = @_;
    my $out;
    my $stroke_width;
    if($hash{"line_width"} < $LINE_MINIMAL_WIDTH) {
        $stroke_width= $LINE_MINIMAL_WIDTH; }
    else {$stroke_width = $hash{"line_width"}; }

    $out .= q[ stroke-width="].$stroke_width
            .q[" stroke="].color2SVG($hash{"color"})
            .q[" ];
    return $out;
}

# encode XML entities
sub text2xml {
    ($_) = @_;
    s/</&lt;/g;
    s/>/&gt;/g;
    s/&/&amp;/g;
    return $_;
}

# register in extremum hash the two points (x1,y1) (x2,y2).
sub extremum {
    my($extremum, $x1, $y1, $x2, $y2) = @_;
    $x1 > $$extremum{"xmax"} and $$extremum{"xmax"} = $x1;
    $x2 > $$extremum{"xmax"} and $$extremum{"xmax"} = $x2;
    $x1 < $$extremum{"xmin"} and $$extremum{"xmin"} = $x1;
    $x2 < $$extremum{"xmin"} and $$extremum{"xmin"} = $x2;

    $y1 > $$extremum{"ymax"} and $$extremum{"ymax"} = $y1;
    $y2 > $$extremum{"ymax"} and $$extremum{"ymax"} = $y2;
    $y1 < $$extremum{"ymin"} and $$extremum{"ymin"} = $y1;
    $y2 < $$extremum{"ymin"} and $$extremum{"ymin"} = $y2;

}

# find the file path for a part
# ex.: findLib("resistance-1.sym") = "/usr/share/gEDA/analog/resistance-1.sym"
sub findLib {
    my ($partname) = @_;

    my $dir;
    my $file;
    my $libfile;
    opendir(PATH,$LIBS_PATH);
    DIR_LOOP: while (defined($dir = readdir(PATH))) {
        if(-d "$LIBS_PATH/$dir" and $dir ne '.' and $dir ne '..') {
            opendir(DIR,"$LIBS_PATH/$dir");
            FILE_LOOP: while (defined($file = readdir(DIR))) {
                if ($file eq $partname) {
                    $libfile = "$LIBS_PATH/$dir/$file";
                    closedir(DIR);
                    last DIR_LOOP;
                }
            }
            closedir(DIR);
        }
    }
    closedir(PATH);

    return $libfile;
}

# encode an id attribut to be xml conform
# an id must be a Name, see http://www.w3.org/TR/2000/REC-xml-20001006#NT-Name
sub encodeId {
    my($name) = @_;
    return "part_".$name; # must start with a letter
}

#####################################
# Parse functions
#####################################
#
# parseXXX take a .sch file line as argument and evaluate is content.
# It return an hash "variable_name" => value. The variable names are most of the time
# the same as in the .sch file format doc (see http://geda.seul.org/docs/fileformats.html).
# All functions convert the y bottom-to-top axe of gschem in the top-to-bottom of svg.
sub parseComponent {
    my($line) = @_;

    my %comp;

    if ( $line =~/C (-?\d+) (-?\d+) (0|1) (0|90|180|270|rotation) (0|1) (.+)/) {
        $comp{"x"} = $1;
        $comp{"y"} = -$2;
        $comp{"selectable"} = $3;
        $comp{"angle"} = $4;
        $comp{"mirror"} = $5;
        $comp{"basename"} = $6;
        chomp($comp{"basename"});

        return %comp;
    }
    else {
        die("parse error of line '$line'");
    }
}

# the next line, the text string must be added by yourself
sub parseText {
    my($line) = @_;

    my %text;

    if ( $line =~/T (-?\d+) (-?\d+) (-?\d+) (-?\d+) (0|1) (0|1|2) (0|90|180|270|rotation) ([0-8])/) {
        $text{"x"} = $1;
        $text{"y"} = -$2;
        $text{"color"} = $3;  # see include/colors.h
        $text{"size"} = $4;
        $text{"visible"} = $5;
        $text{"show_name_value"} = $6;
        $text{"angle"} = $7;
        $text{"alignment"} = $8;

        return %text;
    }
    else {
        die("parse error of line '$line'");
    }
}

sub parseBox {
    my($line) = @_;

    my %box;

    if ( $line =~/B (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (0|1|2) ([0-4]) (-?\d+) (-?\d+) 0 (-1|0) -1 -1 -1 -1/) {
        $box{"x"} = $1;
        $box{"y"} = -$2;
        $box{"width"} = $3;
        $box{"height"} = $4;
        $box{"color"} = $5;  # see include/colors.h
        $box{"line_width"} = $6;
        $box{"line_end"} = $7;
        $box{"line_type"} = $8;
        if( $box{"line_type"} ne "solid") {
            if( $box{"line_type"} eq "dotted") {
                $box{"line_space"} = $9;
            }
            else {
                $box{"line_length"} = $9;
                $box{"line_space"} = $10;
            }
        }
        $box{"y"} = $box{"y"} - $box{"height"}; # y axes differance
        return %box;
    }
    else {
        die("parse error of line '$line'");
    }
}


sub parseNetPinBus {
    my($line) = @_;

    my %hash;

    if ( $line =~/(N|P|U) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+)/) {
        $hash{"type"} = $1;
        $hash{"x1"} = $2;
        $hash{"y1"} = -$3;
        $hash{"x2"} = $4;
        $hash{"y2"} = -$5;
        $hash{"color"} = $6;  # see include/colors.h

        return %hash;
    }
    else {
        die("parse error of line '$line'");
    }
}

sub parseLine {
    my($line) = @_;

    my %hash;

    if ( $line =~/(L) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (0|1|2) ([0-4]) (-?\d+) (-?\d+)( (-?\d+))?/) {
        $hash{"type"} = $1;
        $hash{"x1"} = $2;
        $hash{"y1"} = -$3;
        $hash{"x2"} = $4;
        $hash{"y2"} = -$5;
        $hash{"color"} = $6;  # see include/colors.h
        $hash{"line_width"} = $7;
        $hash{"line_end"} = $LINE_END{$8};
        $hash{"line_type"} = $LINE_TYPE{$9};
        if( $hash{"line_type"} ne "solid") {
            if( $hash{"line_type"} eq "dotted") {
                $hash{"line_space"} = $10;
            }
            else {
                $hash{"line_length"} = $10;
                $hash{"line_space"} = $11;
            }
        }

        return %hash;
    }
    else {
        die("parse error of line '$line'");
    }
}

sub parseCircle {
    my($line) = @_;

    my %circle;

    if ( $line =~/V (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (0|1|2) ([0-4]) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+)/) {
        $circle{"type"} = "circle";
        $circle{"x"} = $1;
        $circle{"y"} = -$2;
        $circle{"radius"} = $3;
        $circle{"color"} = $4;
        $circle{"line_width"} = $5;
        $circle{"line_end"} = $6;
        $circle{"line_type"} = $7;
        if( $circle{"line_type"} ne "solid") {
            if( $circle{"line_type"} eq "dotted") {
                $circle{"line_space"} = $8;
            }
            else {
                $circle{"line_length"} = $8;
                $circle{"line_space"} = $9;
            }
        }

        return %circle;
    }
    else {
        die("parse error of line '$line'");
    }
}

sub parseArc {
    my($line) = @_;

    my %arc;

    if ( $line =~/A (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (-?\d+) (0|1|2) ([0-4])( (-?\d+))?( (-?\d+))?/) {
        $arc{"type"} = "circle";
        $arc{"x"} = $1;
        $arc{"y"} = -$2;
        $arc{"radius"} = $3;
        $arc{"start_angle"} = $4; # in degrees / Standard cartesian layout
        $arc{"sweep_angle"} = $5;
        $arc{"color"} = $6;
        $arc{"line_width"} = $7;
        $arc{"line_end"} = $8;
        $arc{"line_type"} = $9;
        if( $arc{"line_type"} ne "solid") {
            if( $arc{"line_type"} eq "dotted") {
                $arc{"line_space"} = $10;
            }
            else {
                $arc{"line_length"} = $10;
                $arc{"line_space"} = $11;
            }
        }

        return %arc;
    }
    else {
        die("parse error of line '$line'");
    }
}


#####################################
# main parse function
#####################################
# this function take a file handle reference and an hash reference.
# It parse the handle and generate the svg code. The parts used are writed in
# $$svgDefs, the content of <defs></defs>. The schema is writed in $$svgBody.
# The needed parts are included in %$libs with their extremum,
# for ex. $$libs{"lm135-1.sym"}= $extrhash.
sub parse {
    my ($FILE_SCH, $libs,$extr, $svgDefs, $svgBody) = @_;
    my $line;
    my $inAttr = $FALSE;

    my $k = join('|', keys(%OBJECT_TYPE));
    while ($line = <$FILE_SCH>) {
        if ($line =~ /^($k|\[|\{|\})/) {
            my $type = $OBJECT_TYPE{$1};

            if ($1 eq "{") {
                $inAttr = $TRUE;
            }
            elsif ($1 eq "}") {
                $inAttr = $FALSE;
            }
            elsif ($type eq "version") {
                $line =~ /v (.+)/;
                $$svgBody .= "\n<!-- file created with gEDA version $1 -->";
            }
            elsif ($type eq "line") {
                my %line2 = parseLine($line);
                $$svgBody .= "\n<line ".hash2attr(\%line2,"x1","y1", "x2", "y2")
                                .lineAttr(%line2)." />";
                extremum($extr,$line2{'x1'},$line2{'y1'},$line2{'x2'},$line2{'y2'});
            }
            elsif ($type eq "text") {
                my %text = parseText($line);
                my $string = <$FILE_SCH>;
                chomp($string);
                if($inAttr == $TRUE) {
                    $string =~ s/([^=]+)=//;
                    $$svgBody .= "\n<!-- attribut ".$1."='$string' -->";
                }
                if ($text{"visible"}) {
                    if( ($inAttr == $FALSE) # attribut not in {} are not displayed (for ex. in lib)
                        and ( $string =~ /^[A-Za-z]+=/) ) { # attribut name definition ?
                    }
                    else {
                        extremum($extr,$text{'x'},$text{'y'},$text{'x'},$text{'y'});
                        my $textSize = $text{"size"}*14; # 1pt ~ 14 mil
                        $$svgBody .= "\n<text ".hash2attr(\%text,"x","y")
                                .q[ font-size="].$textSize.q[pt">]
                                .text2xml($string)."</text>";
                    }
                }
            }
            elsif ($type eq "box") {
                my %box = parseBox($line);
                $$svgBody .="\n<rect ".hash2attr(\%box,"x","y","width","height").q[ fill="none" ]
                .lineAttr(%box)." />";
                extremum($extr,$box{'x'},$box{'y'},
                            $box{'x'}+$box{'width'},
                            $box{'y'}+$box{'height'});
            }
            elsif ($type eq "circle") {
                my %c = parseCircle($line);
                extremum($extr, $c{'x'}-$c{'radius'},
                                $c{'y'}-$c{'radius'},
                                $c{'x'}+$c{'radius'},
                                $c{'y'}+$c{'radius'});

                $$svgBody .="\n<circle cx=\"".$c{"x"}.q[" cy="].$c{"y"}.q[" r="].$c{"radius"}
                .q[" fill="none" ].lineAttr(%c).q[ />];
            }
            elsif ($type eq "arc") {
                my %arc = parseArc($line);
                # the angle 0 in .sch start at (-r,0) and not (r,0) (math)
                my $startangle = $arc{'start_angle'}*$PI/180 ;
                my $endangle = ($arc{'start_angle'}+$arc{'sweep_angle'})*$PI/180 ;
                my $r = $arc{'radius'};
                my $xstart = $r*cos($startangle);
                my $ystart = -$r*sin($startangle);
                my $xend = $r*cos($endangle);
                my $yend = -$r*sin($endangle);
                $$svgBody .="\n<path d=\""
                            .'M'.$arc{'x'}
                            .','.$arc{'y'}
                            .' m'.$xstart.',' # start point
                            .$ystart
                            .' a'.$r.','.$r
                            .' 0 '; # no  x-axis-rotation
                            if($arc{'sweep_angle'} > 180) { # large-arc-flag
                                $$svgBody .= '1';
                            } else {
                                $$svgBody .= '0';
                            }
                            if($arc{'sweep_angle'} < 0) { # sweep-flag
                                $$svgBody .= ',1 ';
                            } else {
                                $$svgBody .= ',0 ';
                            }
                            $$svgBody .= ($xend - $xstart).',' # deplacement
                            .($yend - $ystart)

                            .q[" fill="none" ].lineAttr(%arc).q[ />];
                extremum($extr, $arc{'x'}+$xstart, $arc{'y'}+$ystart,
                                $arc{'x'}+$xend, $arc{'y'}+$yend);

            }
            elsif ($type eq "net") {
                my %net = parseNetPinBus($line);
                extremum($extr,$net{'x1'},$net{'y1'},$net{'x2'},$net{'y2'});
                $$svgBody .= "\n<line ".hash2attr(\%net,"x1","y1", "x2", "y2").$STYLE_OF_NET." />";
            }
            elsif ($type eq "bus") {
                my %bus = parseNetPinBus($line);
                extremum($extr,$bus{'x1'},$bus{'y1'},$bus{'x2'},$bus{'y2'});
                $$svgBody .= "\n<line ".hash2attr(\%bus,"x1","y1", "x2", "y2").$STYLE_OF_BUS." />";
            }
            elsif ($type eq "pin") {
                my %pin = parseNetPinBus($line);
                extremum($extr,$pin{'x1'},$pin{'y1'},$pin{'x2'},$pin{'y2'});
                $$svgBody .= "\n<line ".hash2attr(\%pin,"x1","y1", "x2", "y2").$STYLE_OF_PIN." />";
            }
            elsif ($type eq "componement") {
                my %comp = parseComponent($line);
                my $partextr;
                my $part = $comp{"basename"};
                if (exists $$libs{$part}) {
                    $partextr = $$libs{$part};
                }
                else {
                    my $libfile = findLib($part);
                    if(-f $libfile ) {
                        $partextr = {'xmin',100000,'xmax',-100000,'ymin', 100000, 'ymax', -100000  };
                        open(LIB,"<$libfile") or die("unable to open $libfile");
                        $$svgDefs .= "\n<g id=\"".encodeId($part).'">';   # <symbol> will be better, but doesn't work now
                        my %sublib;
                        my $subdefs;
                        parse(*LIB, \%sublib, $partextr, \$subdefs, $svgDefs);
                        $$svgDefs .= "\n</g>";
                        $$libs{$comp{"basename"}} = $partextr;
                    }
                    else {
                    die("symbol $part not found in $LIBS_PATH\n");
                    }
                }
                extremum($extr, $comp{'x'}+$$partextr{'xmin'},
                                $comp{'y'}+$$partextr{'ymin'},
                                $comp{'x'}+$$partextr{'xmax'},
                                $comp{'y'}+$$partextr{'ymax'});

                $$svgBody .= "\n<use xlink:href=\"#".encodeId($comp{"basename"}).q[" ]
                            .hash2attr(\%comp,"x","y").' transform="';
                if(($comp{'angle'} ne '0') and ($comp{'angle'} ne 'rotation') ) {
                    $$svgBody .= "rotate(-".$comp{'angle'}.')'; # negativ -> y axes change
                }
                if($comp{'mirror'} eq 1) {
                    $$svgBody .= " scale(-1 1)";
                }
                $$svgBody .= '" />';

            }
        }
    }
}


#############################################################
# main program
#############################################################

# parse the .sch file
open(FILE_SCH, "<$ARGV[0]") or die("file $ARGV[0] invalide");
my %libs;
my $extr = {'xmin',100000,'xmax',-100000,'ymin', 100000, 'ymax', -100000  };
my $svgBody;
my $svgDefs = "\n<defs>";
parse(*FILE_SCH, \%libs, $extr, \$svgDefs, \$svgBody);
$svgDefs .= "\n</defs>";

# create the SVG header
# the unity of gschem in 1/1000 of inch
my $totalwith = $$extr{'xmax'}-$$extr{'xmin'};
my $totalheight = $$extr{'ymax'}-$$extr{'ymin'};
my $svgHeader =
q[<?xml version="1.0" standalone="no"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.0//EN"
  "http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd">
<!-- producted by sch2svg version ].$VERSION.q[ -->
<svg width="].($totalwith/1000).q[in" height="].($totalheight/1000)
.q[in" viewBox="0 0 ];
$svgHeader .= $totalwith;
$svgHeader .= " ";
$svgHeader .= $totalheight;
$svgHeader .= q["
  xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
];

# move the schema to the point 0,0
$svgBody = "\n<g transform=\"translate(".
            -$$extr{'xmin'}.','.-$$extr{'ymin'}.q[)">]
            .$svgBody."\n</g>";

# write in the output file
my $svgfile = $ARGV[1];
open(SVG, ">$svgfile") or die("unable to open '$svgfile'");

print SVG $svgHeader;
print SVG $svgDefs;
print SVG $svgBody;
print SVG "\n</svg>";

close(FILE_SCH);
close(SVG);
